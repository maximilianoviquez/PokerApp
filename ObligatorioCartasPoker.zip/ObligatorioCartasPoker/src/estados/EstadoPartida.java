
package estados;


public enum EstadoPartida {
    ABIERTA,
    JUGANDO,
    FINALIZADA;
}

