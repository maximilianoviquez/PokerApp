
package estados;


public enum EstadoMano  {
    ESPERANDO_APUESTA,
    APUESTA_INICIADA,
    PIDIENDO_CARTAS,
    TERMINADA;
    
}
