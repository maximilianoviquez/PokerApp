
package estados;


public enum EstadoJugador {
    ACCION_PENDIENTE,
    APUESTA_INICIADA,
    APUESTA_PAGADA,
    PASO
}
