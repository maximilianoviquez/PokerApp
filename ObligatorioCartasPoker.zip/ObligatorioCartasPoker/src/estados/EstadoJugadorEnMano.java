
package estados;


public enum EstadoJugadorEnMano {
    ACCION_PENDIENTE,
    APUESTA_INICIADA,
    APUESTA_PAGADA,
    PASO
}
