
package pokerApp.Exceptions;

public class ManoException extends Exception {
    public ManoException(String mensaje){
        super(mensaje);
    }
}
