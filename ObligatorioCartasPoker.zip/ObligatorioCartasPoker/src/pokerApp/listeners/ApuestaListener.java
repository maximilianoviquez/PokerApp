
package pokerApp.listeners;

public interface ApuestaListener {
    public void apuestaIngresada(float monto);
}
