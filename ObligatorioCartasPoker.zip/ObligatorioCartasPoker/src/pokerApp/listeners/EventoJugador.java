
package pokerApp.listeners;


public enum EventoJugador{
    NO_TIENE_SALDO_SUFICIENTE;
}
