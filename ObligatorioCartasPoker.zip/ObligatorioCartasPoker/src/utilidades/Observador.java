package utilidades;

public interface Observador {
    void actualizar(Observable origen, Object evento);
}