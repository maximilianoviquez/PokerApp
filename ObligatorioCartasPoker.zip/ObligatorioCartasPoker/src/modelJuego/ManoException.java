
package modelJuego;

public class ManoException extends Exception {
    public ManoException(String mensaje){
        super(mensaje);
    }
}
