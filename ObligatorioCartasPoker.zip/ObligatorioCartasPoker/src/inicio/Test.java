
package inicio;



public class Test {
 
    public static void main(String[] args){
        DatosPrueba.cargar();
        Principal principal = new Principal();
        principal.setVisible(true);
        
    }
}
